const stories=[
{id:1,cat:'Nigeria',icon:'🇳🇬',title:'Nigeria news and public updates in one place',text:'A dedicated space for verified national developments, public announcements and stories affecting everyday life.',body:'Silas News uses this local story area for clear, readable coverage of important Nigerian developments. Replace this sample with your own verified report when publishing a real story.'},
{id:2,cat:'Education',icon:'🎓',title:'Education and university updates',text:'Follow admissions, examinations, scholarships and opportunities for students.',body:'Education coverage can include university admissions, examination information, scholarships, competitions and useful opportunities for students.'},
{id:3,cat:'Technology',icon:'🤖',title:'AI and technology developments',text:'Understand major technology stories without complicated language.',body:'The technology desk explains AI, apps, digital tools, cybersecurity and other technology developments in simple language.'},
{id:4,cat:'World',icon:'🌍',title:'Major world developments',text:'A space for important international stories and global events.',body:'The World Desk is designed for major international developments. Add a verified report, source and publication time before treating a sample story as current news.'},
{id:5,cat:'Sports',icon:'⚽',title:'Sports stories and results',text:'Follow major football and sporting developments.',body:'The Sports Desk can carry match results, fixtures, transfers, tournaments and other sporting stories. Always verify live results before publishing them.'},
{id:6,cat:'Entertainment',icon:'🎬',title:'Entertainment and culture',text:'Movies, music, creators and culture updates.',body:'Entertainment coverage can highlight film, music, creators, events and culture in a short, readable format.'},
{id:7,cat:'Nigeria',icon:'📢',title:'How to make local updates easier to follow',text:'Use short headlines, clear dates and a visible source when publishing national stories.',body:'Good news presentation makes the key point easy to understand. Keep the headline specific, include the date and identify the source of important claims.'},
{id:8,cat:'Education',icon:'📚',title:'Scholarships and student opportunities',text:'A dedicated area for competitions, scholarships, hackathons and youth opportunities.',body:'Opportunity stories should include eligibility, deadline, official application information and any important requirements.'}
];
const cats=['All','Nigeria','World','Technology','Education','Sports','Entertainment'];
let activeCat='All';
const $=id=>document.getElementById(id);
function dateText(){return new Intl.DateTimeFormat('en-NG',{weekday:'long',year:'numeric',month:'long',day:'numeric'}).format(new Date())}
function render(){
 $('today').textContent=dateText(); $('year').textContent=new Date().getFullYear();
 $('filters').innerHTML=cats.map(c=>`<button class="filter ${activeCat===c?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join('');
 const filtered=activeCat==='All'?stories:stories.filter(s=>s.cat===activeCat); $('newsGrid').innerHTML=filtered.map(card).join('');
 ['Nigeria','World','Technology','Education','Sports','Entertainment'].forEach(cat=>{
  const target=$(cat.toLowerCase()+'Grid'); const items=stories.filter(s=>s.cat===cat).slice(0,3);
  if(cat==='Education') target.innerHTML=items.map(eduCard).join(''); else target.innerHTML=items.map(card).join('');
 });
 const f=stories[1]; $('featuredTitle').textContent=f.title; $('featuredText').textContent=f.text; $('featuredDate').textContent='Updated locally • Silas News';
}
function card(s){return `<article class="card" onclick="openArticle(${s.id})"><div class="thumb">${s.icon}</div><div class="card-content"><span class="tag">${s.cat}</span><h3>${s.title}</h3><p>${s.text}</p><small>Sample story • ${dateText()}</small><b class="read">Read story →</b></div></article>`}
function eduCard(s){return `<article class="edu" onclick="openArticle(${s.id})"><div class="edu-number">${String(s.id).padStart(2,'0')}</div><div><h3>${s.title}</h3><p>${s.text}</p><b class="read">Read story →</b></div></article>`}
function setCategory(c){activeCat=c;render();location.hash='latest'}
function refreshNews(){$('tickerText').textContent='News feed refreshed — '+new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});render()}
function toggleMenu(){$('navlinks').classList.toggle('open')}
function toggleTheme(){document.body.classList.toggle('darkmode');localStorage.setItem('silasDark',document.body.classList.contains('darkmode'))}
function openSearch(){const p=$('searchPanel');p.classList.add('show');p.setAttribute('aria-hidden','false');$('searchInput').focus()}
function closeSearch(){const p=$('searchPanel');p.classList.remove('show');p.setAttribute('aria-hidden','true')}
function searchStories(){const q=$('searchInput').value.trim().toLowerCase();const results=stories.filter(s=>(s.title+' '+s.text+' '+s.cat).toLowerCase().includes(q)).slice(0,8);$('searchResults').innerHTML=q?(results.length?results.map(s=>`<button onclick="openArticle(${s.id});closeSearch()"><span>${s.icon}</span><div><b>${s.title}</b><small>${s.cat}</small></div></button>`).join(''):'<p>No stories found.</p>'):'<p>Type a keyword to search Silas News.</p>'}
function openArticle(id){const s=stories.find(x=>x.id===id);if(!s)return;$('modalTag').textContent=s.cat;$('modalTitle').textContent=s.title;$('modalMeta').textContent=`${s.icon} Silas News • ${dateText()}`;$('modalBody').innerHTML=`<p>${s.text}</p><p>${s.body}</p><p class="notice">Prototype note: this story is local sample content, not a live news report.</p>`;$('articleModal').classList.add('show');document.body.classList.add('modal-open')}
function openFeatured(){openArticle(2)}
function closeArticle(){$('articleModal').classList.remove('show');document.body.classList.remove('modal-open')}
function useSuggestion(q){$('question').value=q;askAI()}
function askAI(){const q=$('question').value.trim().toLowerCase();if(!q){$('answer').textContent='Type a question first.';return}let matches=stories.filter(s=>(s.title+' '+s.text+' '+s.cat+' '+s.body).toLowerCase().includes(q.replace(/what|is|the|latest|story|stories|about|here|news|are|in/g,' ').trim())||q.includes(s.cat.toLowerCase()));if(!matches.length)matches=stories.filter(s=>q.includes(s.cat.toLowerCase())||s.cat.toLowerCase().includes(q));if(matches.length){const s=matches[0];$('answer').innerHTML=`<b>${s.title}</b><br>${s.text}<br><button class="inline-read" onclick="openArticle(${s.id})">Read this story →</button>`}else $('answer').textContent='I could not find that topic in the stories stored on this website. Try Nigeria, Education, Technology, World, Sports or Entertainment.'}
$('articleModal').addEventListener('click',e=>{if(e.target.id==='articleModal')closeArticle()});document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeArticle();closeSearch()}});
if(localStorage.getItem('silasDark')==='true')document.body.classList.add('darkmode');render();
